rg.exe(Random Generator)是我的作品，其特点为功能齐全，UI古董，可以自定义。
如果打不开，可以尝试把options.txt里的第一个数字改为1，但这样会使关闭按钮失效。